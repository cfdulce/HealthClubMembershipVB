﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        grpTypeOfMembership = New GroupBox()
        radSenior = New RadioButton()
        radStudent = New RadioButton()
        radChild = New RadioButton()
        radAdult = New RadioButton()
        grpOptions = New GroupBox()
        chkTrainer = New CheckBox()
        chkKarate = New CheckBox()
        chkYoga = New CheckBox()
        grpMembershipLength = New GroupBox()
        txtMonths = New TextBox()
        lblMonths = New Label()
        grpMembershipFees = New GroupBox()
        lblTotalFee = New Label()
        lblMonthlyFee = New Label()
        txtTotalFee = New TextBox()
        txtMonthlyFee = New TextBox()
        btnCalculate = New Button()
        btnClear = New Button()
        btnExit = New Button()
        grpTypeOfMembership.SuspendLayout()
        grpOptions.SuspendLayout()
        grpMembershipLength.SuspendLayout()
        grpMembershipFees.SuspendLayout()
        SuspendLayout()
        ' 
        ' grpTypeOfMembership
        ' 
        grpTypeOfMembership.BackColor = SystemColors.MenuBar
        grpTypeOfMembership.Controls.Add(radSenior)
        grpTypeOfMembership.Controls.Add(radStudent)
        grpTypeOfMembership.Controls.Add(radChild)
        grpTypeOfMembership.Controls.Add(radAdult)
        grpTypeOfMembership.Location = New Point(127, 72)
        grpTypeOfMembership.Name = "grpTypeOfMembership"
        grpTypeOfMembership.Size = New Size(413, 255)
        grpTypeOfMembership.TabIndex = 0
        grpTypeOfMembership.TabStop = False
        grpTypeOfMembership.Text = "Type of Membership"
        ' 
        ' radSenior
        ' 
        radSenior.AutoSize = True
        radSenior.Location = New Point(33, 178)
        radSenior.Name = "radSenior"
        radSenior.Size = New Size(222, 51)
        radSenior.TabIndex = 3
        radSenior.TabStop = True
        radSenior.Text = "Senior Citizen"
        radSenior.UseVisualStyleBackColor = True
        ' 
        ' radStudent
        ' 
        radStudent.AutoSize = True
        radStudent.Location = New Point(33, 133)
        radStudent.Name = "radStudent"
        radStudent.Size = New Size(144, 51)
        radStudent.TabIndex = 2
        radStudent.TabStop = True
        radStudent.Text = "Student"
        radStudent.UseVisualStyleBackColor = True
        ' 
        ' radChild
        ' 
        radChild.AutoSize = True
        radChild.Location = New Point(33, 88)
        radChild.Name = "radChild"
        radChild.Size = New Size(256, 51)
        radChild.TabIndex = 1
        radChild.TabStop = True
        radChild.Text = "Child (12 & under)"
        radChild.UseVisualStyleBackColor = True
        ' 
        ' radAdult
        ' 
        radAdult.AutoSize = True
        radAdult.Location = New Point(33, 40)
        radAdult.Name = "radAdult"
        radAdult.Size = New Size(232, 51)
        radAdult.TabIndex = 0
        radAdult.TabStop = True
        radAdult.Text = "Standard Adult"
        radAdult.UseVisualStyleBackColor = True
        ' 
        ' grpOptions
        ' 
        grpOptions.Controls.Add(chkTrainer)
        grpOptions.Controls.Add(chkKarate)
        grpOptions.Controls.Add(chkYoga)
        grpOptions.Location = New Point(755, 72)
        grpOptions.Name = "grpOptions"
        grpOptions.Size = New Size(336, 246)
        grpOptions.TabIndex = 1
        grpOptions.TabStop = False
        grpOptions.Text = "Options"
        ' 
        ' chkTrainer
        ' 
        chkTrainer.AutoSize = True
        chkTrainer.Location = New Point(20, 178)
        chkTrainer.Name = "chkTrainer"
        chkTrainer.Size = New Size(267, 51)
        chkTrainer.TabIndex = 2
        chkTrainer.Text = "Personal Training"
        chkTrainer.UseVisualStyleBackColor = True
        ' 
        ' chkKarate
        ' 
        chkKarate.AutoSize = True
        chkKarate.Location = New Point(20, 121)
        chkKarate.Name = "chkKarate"
        chkKarate.Size = New Size(131, 51)
        chkKarate.TabIndex = 1
        chkKarate.Text = "Karate"
        chkKarate.UseVisualStyleBackColor = True
        ' 
        ' chkYoga
        ' 
        chkYoga.AutoSize = True
        chkYoga.Location = New Point(20, 62)
        chkYoga.Name = "chkYoga"
        chkYoga.Size = New Size(111, 51)
        chkYoga.TabIndex = 0
        chkYoga.Text = "Yoga"
        chkYoga.UseVisualStyleBackColor = True
        ' 
        ' grpMembershipLength
        ' 
        grpMembershipLength.Controls.Add(txtMonths)
        grpMembershipLength.Controls.Add(lblMonths)
        grpMembershipLength.Location = New Point(127, 392)
        grpMembershipLength.Name = "grpMembershipLength"
        grpMembershipLength.Size = New Size(405, 225)
        grpMembershipLength.TabIndex = 2
        grpMembershipLength.TabStop = False
        grpMembershipLength.Text = "Membership Length"
        ' 
        ' txtMonths
        ' 
        txtMonths.BackColor = SystemColors.ControlLight
        txtMonths.Location = New Point(122, 128)
        txtMonths.Name = "txtMonths"
        txtMonths.Size = New Size(159, 48)
        txtMonths.TabIndex = 1
        ' 
        ' lblMonths
        ' 
        lblMonths.AutoSize = True
        lblMonths.Location = New Point(25, 67)
        lblMonths.Name = "lblMonths"
        lblMonths.Size = New Size(370, 47)
        lblMonths.TabIndex = 0
        lblMonths.Text = "Enter the Number of Months"
        ' 
        ' grpMembershipFees
        ' 
        grpMembershipFees.Controls.Add(lblTotalFee)
        grpMembershipFees.Controls.Add(lblMonthlyFee)
        grpMembershipFees.Controls.Add(txtTotalFee)
        grpMembershipFees.Controls.Add(txtMonthlyFee)
        grpMembershipFees.Location = New Point(755, 392)
        grpMembershipFees.Name = "grpMembershipFees"
        grpMembershipFees.Size = New Size(336, 225)
        grpMembershipFees.TabIndex = 3
        grpMembershipFees.TabStop = False
        grpMembershipFees.Text = "Membership Fees"
        ' 
        ' lblTotalFee
        ' 
        lblTotalFee.AutoSize = True
        lblTotalFee.Location = New Point(81, 145)
        lblTotalFee.Name = "lblTotalFee"
        lblTotalFee.Size = New Size(80, 47)
        lblTotalFee.TabIndex = 3
        lblTotalFee.Text = "Total"
        ' 
        ' lblMonthlyFee
        ' 
        lblMonthlyFee.AutoSize = True
        lblMonthlyFee.Location = New Point(30, 67)
        lblMonthlyFee.Name = "lblMonthlyFee"
        lblMonthlyFee.Size = New Size(168, 47)
        lblMonthlyFee.TabIndex = 2
        lblMonthlyFee.Text = "Monthly Fee"
        ' 
        ' txtTotalFee
        ' 
        txtTotalFee.BackColor = SystemColors.ControlLight
        txtTotalFee.Location = New Point(204, 145)
        txtTotalFee.Name = "txtTotalFee"
        txtTotalFee.ReadOnly = True
        txtTotalFee.Size = New Size(100, 48)
        txtTotalFee.TabIndex = 1
        ' 
        ' txtMonthlyFee
        ' 
        txtMonthlyFee.BackColor = SystemColors.ControlLight
        txtMonthlyFee.Location = New Point(204, 67)
        txtMonthlyFee.Name = "txtMonthlyFee"
        txtMonthlyFee.ReadOnly = True
        txtMonthlyFee.Size = New Size(100, 48)
        txtMonthlyFee.TabIndex = 0
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = SystemColors.Control
        btnCalculate.Location = New Point(348, 676)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(157, 63)
        btnCalculate.TabIndex = 4
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = SystemColors.Control
        btnClear.Location = New Point(561, 676)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(121, 63)
        btnClear.TabIndex = 5
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = SystemColors.Control
        btnExit.Location = New Point(733, 676)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(111, 63)
        btnExit.TabIndex = 6
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(16F, 47F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.MenuBar
        BackgroundImage = My.Resources.Resources.gymPic
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(1239, 809)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(btnCalculate)
        Controls.Add(grpMembershipFees)
        Controls.Add(grpMembershipLength)
        Controls.Add(grpOptions)
        Controls.Add(grpTypeOfMembership)
        Font = New Font("Sitka Banner", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Margin = New Padding(5, 4, 5, 4)
        Name = "Form1"
        Text = "Membership Fee Calculator"
        grpTypeOfMembership.ResumeLayout(False)
        grpTypeOfMembership.PerformLayout()
        grpOptions.ResumeLayout(False)
        grpOptions.PerformLayout()
        grpMembershipLength.ResumeLayout(False)
        grpMembershipLength.PerformLayout()
        grpMembershipFees.ResumeLayout(False)
        grpMembershipFees.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents grpTypeOfMembership As GroupBox
    Friend WithEvents grpOptions As GroupBox
    Friend WithEvents grpMembershipLength As GroupBox
    Friend WithEvents grpMembershipFees As GroupBox
    Friend WithEvents radSenior As RadioButton
    Friend WithEvents radStudent As RadioButton
    Friend WithEvents radChild As RadioButton
    Friend WithEvents radAdult As RadioButton
    Friend WithEvents chkTrainer As CheckBox
    Friend WithEvents chkKarate As CheckBox
    Friend WithEvents chkYoga As CheckBox
    Friend WithEvents txtMonths As TextBox
    Friend WithEvents lblMonths As Label
    Friend WithEvents lblTotalFee As Label
    Friend WithEvents lblMonthlyFee As Label
    Friend WithEvents txtTotalFee As TextBox
    Friend WithEvents txtMonthlyFee As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button


    '===============================================================PROJECT CODE===========================================================================

    'Declare Variables
    Dim membershipTypeFee As Integer
    Dim exerciseFee
    Dim TotalMonthlyFee As Integer
    Dim membershipLength As Integer
    Dim totalFee As Integer
    Private Sub grpTypeOfMembership_Enter(sender As Object, e As EventArgs) Handles grpTypeOfMembership.Enter
        If radAdult.Checked = True Then
            membershipTypeFee = 25 'set cost for adults
        ElseIf radChild.Checked = True Then
            membershipTypeFee = 15 'set cost for children
        ElseIf radStudent.Checked = True Then
            membershipTypeFee = 12 'set cost for student
        ElseIf radSenior.Checked = True Then
            membershipTypeFee = 17 'set cost for seniors
        End If
    End Sub

    Private Sub grpOptions_Enter(sender As Object, e As EventArgs) Handles grpOptions.Enter
        If chkYoga.Checked = True Then 'added cost for yoga
            exerciseFee += 10
        End If
        If chkKarate.Checked = True Then 'added cost for karate
            exerciseFee += 30
        End If
        If chkTrainer.Checked = True Then 'added cost for personal trainer
            exerciseFee += 50
        End If
    End Sub
    Private Sub txtMonths_TextChanged(sender As Object, e As EventArgs) Handles txtMonths.TextChanged
        If Not Integer.TryParse(txtMonths.Text, membershipLength) Then
            MessageBox.Show("Please input an integer value")
        End If
    End Sub

    Private Sub txtMonthlyFee_TextChanged(sender As Object, e As EventArgs) Handles txtMonthlyFee.TextChanged
        TotalMonthlyFee = membershipTypeFee + exerciseFee
        txtMonthlyFee.Show()

    End Sub

    Private Sub txtTotalFee_TextChanged(sender As Object, e As EventArgs) Handles txtTotalFee.TextChanged
        totalFee = (membershipTypeFee + exerciseFee) * membershipLength
        txtTotalFee.Show()
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        'txtMonthlyFee.Show()
        'txtTotalFee.Show()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtMonths.Clear()
        txtMonthlyFee.Clear()
        txtTotalFee.Clear()
        radAdult.Checked = False
        radChild.Checked = False
        radStudent.Checked = False
        radSenior.Checked = False
        chkYoga.Checked = False
        chkKarate.Checked = False
        chkTrainer.Checked = False
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

    End Sub

End Class
